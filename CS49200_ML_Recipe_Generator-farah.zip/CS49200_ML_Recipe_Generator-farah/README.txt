
backend:
.\venv\Scripts\activate
uvicorn main:app --reload


frontend:
npm i (<- if line below does not work)
npm run dev